
import React, { useEffect, useState } from 'react';
import { fetchProducts } from './productApi';

function ProductList() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const productsData = await fetchProducts();
      setProducts(productsData);
    }
    fetchData();
  }, []);

  return (
    <div className="container">
      <h1 style={{ color: '#349696', fontSize: '72px', textAlign: 'center' }}>Microcourses Academy</h1>
      <h1>List of Courses</h1>
      {products.map(product => (
        <div className="product" key={product._id}>
          <h2>{product.name}</h2>
          <p>{product.description}</p>
          <p style={{ fontWeight: 'bold' }}> Duration: {product.duration}</p>
          <p style={{ fontWeight: 'bold' }}> Intructor: {product.instructor}</p>
          <p className="price"> Fee = ${product.price}</p>
        </div>
      ))}
    </div>
  );
}

export default ProductList;
