import React from 'react'

function Courses0() {
    return (
        <div className="container">
            <h1>Welcome to MicroCourses</h1>
            <a href="product_list.html" className="button">
                View Courses <br></br>
            </a>
            <a href="create_product.html" className="button">
                <br></br>Enrol in a Course
            </a>
        </div>

    )
}
export default Courses0

