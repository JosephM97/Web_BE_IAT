// src/data.js
const products = [
  {
    id: 1,
    name: 'Introduction to Cloud Computing',
    description: 'Overview of the case for cloud computing, understanding cloud computing technologies, cloud deployment models and how to get into the Cloud workspace',
    price: 'Free'
  },
  {
    id: 2,
    name: 'Cloud Computing Foundations',
    description: 'Gain an understanding of the similarities and differences between on-premises and cloud applications, types of services available on cloud, and how to identify and acquire cloud computing resources for a given application scenario.',
    price: '$1500'
  },
  {
    id: 3,
    name: 'Cloud Security',
    description: 'Gain an understanding of the common security risks and threats in cloud and cloud applications, how to assess cloud security risks/threats, and how to design security mechanisms for securing cloud applications to minimise risk and threats in a cloud',
    price: '$3000'
  },
  {
    id: 4,
    name: 'Cloud Administration',
    description: 'A hands-on, practical approach to the cloud environment and teaches how to configure and maintain the cloud platform from a cloud administrator’s perspective',
    price: '$4500'
  },
  {
    id: 5,
    name: 'Advanced Cloud Computing',
    description: 'Gain an understanding of how to utilise features of cloud services for creating optimal application architecture, core techniques for designing highly available and cost-effective application architecture, and alternate non-traditional application architecture',
    price: '$5000'
  }
];

export default products;
