// src/App.jsx
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';

import ProductList from './ProductList';
import NewProduct from './NewProduct';
import productsData from './data';
import './styles.css';

import axios from 'axios';
const BASE_URL = 'http://localhost:3000';

// function to fetch products
export async function fetchProducts() {
  try {
    const response = await axios.get(`${BASE_URL}/products`);
    return response.data;
  } catch (error) {
    console.error('Error fetching products:', error);
    return [];
  }
}

// function to create a new product
export async function createProduct(productData) {
  try {
    const response = await axios.post(`${BASE_URL}/products`, productData);
    return response.data;
  } catch (error) {
    console.error('Error creating product:', error);
    return null;
  }
}


const App = () => {
  const [products, setProducts] = useState(productsData);

  const addProduct = (product) => {
    setProducts([...products, product]);
  };

  return (
    <Router>
      <div className="App">
        <nav>
          <ul>
            <li>
              <Link to="/">Course List</Link>
            </li>
            <li>
              <Link to="/new">Add New Course</Link>
            </li>
          </ul>
        </nav>
        <Routes>
          <Route path="/" element={<ProductList products={products} />} />
          <Route path="/new" element={<NewProduct addProduct={addProduct} />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;