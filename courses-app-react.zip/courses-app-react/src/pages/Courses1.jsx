import React from 'react'

function Courses1() {
    return (
        <h1>Courses1</h1>
    )
}
export default Courses1

