import React from 'react'

function Courses3() {
    return (
        <h1>Courses3</h1>
    )
}
export default Courses3

