import React from 'react'

function Courses2() {
    return (
        <h1>Courses2</h1>
    )
}
export default Courses2

