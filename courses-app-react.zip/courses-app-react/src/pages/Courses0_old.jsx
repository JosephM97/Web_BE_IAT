import React from 'react'

function Courses0() {
    return (
        <h1>Home</h1>
    )
}
export default Courses0

