import React from 'react'

function Courses4() {
    return (
        <h1>Courses4</h1>
    )
}
export default Courses4

