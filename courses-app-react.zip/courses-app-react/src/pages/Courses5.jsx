import React from 'react'

function Courses5() {
    return (
        <h1>Courses5</h1>
    )
}
export default Courses5

