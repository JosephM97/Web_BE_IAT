import React from 'react';
import Courses0 from './pages/Courses0';
import Courses1 from './pages/Courses1';
import Courses2 from './pages/Courses2';
import Courses3 from './pages/Courses3';
import Courses4 from './pages/Courses4';
import Courses5 from './pages/Courses5';
import { BrowserRouter as Router, Route, Routes, Link, BrowserRouter } from 'react-router-dom';

function App() {

  return (

    <BrowserRouter>
      <Routes>
        <Route path='/Courses0' element={<Courses0 />} />
        <Route path='/Courses1' element={<Courses1 />} />
        <Route path='/Courses2' element={<Courses2 />} />
        <Route path='/Courses3' element={<Courses3 />} />
        <Route path='/Courses4' element={<Courses4 />} />
        <Route path='/Courses5' element={<Courses5 />} />
      </Routes>
    </BrowserRouter>

  )
}

export default App
